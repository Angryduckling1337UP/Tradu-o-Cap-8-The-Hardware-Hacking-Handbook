﻿CAPITULO 8 (TRADUÇÃO)

EU TENHO A FORÇA: INTRODUÇÃO À ANÁLISE DE ENERGIA

Você ouvirá com frequência que os algoritmos criptográficos são inquebráveis, independentemente dos enormes avanços no poder de computação. É verdade. No entanto, como você aprenderá neste capítulo, a chave para encontrar vulnerabilidades em algoritmos criptográficos está em sua implementação, não importa o quão "militar" eles sejam.

Dito isso, não discutiremos erros de implementação de criptografia, como verificações de limites com falha, neste capítulo. Em vez disso, exploraremos a própria natureza da eletrônica digital usando canais laterais para quebrar algoritmos que, no papel, parecem ser seguros. Um canal lateral é um aspecto observável de um sistema que revela segredos mantidos dentro desse sistema. As técnicas que descrevemos aproveitam vulnerabilidades que surgem da implementação física desses algoritmos em hardware, principalmente na forma como os dispositivos digitais usam a energia. Começaremos com o tempo de execução dependente de dados, que podemos determinar monitorando o consumo de energia, e depois passaremos para o monitoramento do consumo de energia como um meio de identificar bits-chave em funções de processamento criptográfico.

Existe uma precedência histórica considerável para a análise de canal lateral. Por exemplo, durante a Segunda Guerra Mundial, os britânicos estavam interessados em estimar o número de tanques produzidos pelos alemães. A maneira mais confiável de fazer isso acabou sendo uma análise estatística da sequência de números de série de tanques capturados ou desativados, supondo que os números de série normalmente aumentam de maneira direta. Os ataques que apresentaremos neste capítulo espelham esse chamado *Problema dos Tanques Alemães*: eles combinam estatísticas com suposições e, em última análise, usam uma pequena quantidade de dados que nosso adversário nos vazou sem saber.

Outros ataques históricos de canal lateral monitoram sinais eletrônicos não intencionais emanados do hardware. Na verdade, quase tão logo os sistemas eletrônicos foram usados para passar mensagens seguras, eles foram sujeitos a ataques. Um desses ataques iniciais famosos foi o TEMPEST, lançado por cientistas da Bell Labs na Segunda Guerra Mundial para decodificar pressionamentos de teclas de máquina de escrever eletrônica a 80 metros de distância com uma precisão de 75% (veja "TEMPEST: A Signal Problem" da Agência de Segurança Nacional dos EUA). Desde então, o TEMPEST tem sido usado para reproduzir o que está sendo exibido em um monitor de computador, captando as emissões de sinal de rádio do monitor do lado de fora do prédio (ver, por exemplo, "Radiação eletromagnética de unidades de exibição de vídeo: um risco de escuta?", de Wim van Eck). E embora o ataque TEMPEST original tenha usado monitores do tipo CRT, essa mesma vulnerabilidade foi demonstrada em monitores LCD mais recentes por Markus G. Kuhn em "Electromagnetic Eavesdropping Risks of Flat-Panel Displays", então está longe de estar desatualizada.

No entanto, mostraremos algo ainda mais sub-reptício do que TEMPEST: uma maneira de usar emissões não intencionais de hardware para quebrar algoritmos criptográficos seguros de outra forma. Essa estratégia abrange tanto softwares executados em hardware (como firmware em um microcontrolador) quanto implementações de hardware puro dos algoritmos (como aceleradores criptográficos). Descreveremos como medir, como processar sua medição para melhorar o vazamento e como extrair segredos. Abordaremos tópicos que têm suas raízes em áreas que vão desde o design de chips e placas de circuito impresso (PCB), passando por eletrônica, eletromagnetismo e processamento de sinais (digitais), até estatísticas, criptografia e até mesmo o senso comum.

**Temporizando Ataques**

Timing é tudo. Considere o que acontece ao implementar uma verificação de código de número de identificação pessoal (PIN), como uma que você encontraria em um cofre de parede ou alarme de porta. O designer permite que você insira o PIN completo (digamos, quatro dígitos) antes de comparar o PIN inserido com o código secreto armazenado. No código C, poderia parecer algo como a Listagem 8-1.

int checkPassword() { 

Int user\_pin[] = {1, 1, 1, 1}; 

int correct\_pin[] = {5, 9, 8, 2};

` 	`// Disable the error LED 

error\_led\_off();

// Store four most recent buttons

for(int i = 0; i < 4; i++) {

user\_pin[i] = read\_button();

`	`}

`	`// Wait until user presses 'Valid' button 

while(valid\_pressed() == 0);

// Check stored button press with correct PIN

for(int i = 0; i < 4; i++) {

if(user\_pin[i] != correct\_pin[i]) {

error\_led\_on();

return 0;

`		`}

`	`}

`	`return 1;

}

*Listagem 8-1: Verificação de código PIN de exemplo escrita em C*

Parece um código bastante razoável, certo? Lemos em quatro dígitos. Se eles corresponderem ao código secreto, a função retornará um 1; caso contrário, ele retorna um 0. Em última análise, podemos usar esse valor de retorno para abrir um cofre ou desarmar o sistema de segurança pressionando o botão válido após os quatro dígitos terem sido inseridos. Um LED de erro vermelho acende para mostrar que o PIN está incorreto.

Como esse cofre pode ser atacado? Supondo que o PIN aceite os números de 0 a 9, testar todas as combinações possíveis exigiria um total de 10 × 10 × 10 × 10 = 10.000 palpites. Em média, teríamos que executar 5.000 palpites para encontrar o PIN, mas isso levaria muito tempo, e o sistema poderia limitar a velocidade na qual podemos inserir palpites repetidamente.

Felizmente, podemos reduzir o número de palpites para 40 usando uma técnica chamada ataque de temporização. Suponha que temos o teclado mostrado na Figura 8-1. A tecla C (para limpar) limpa a entrada e a tecla V (para válido) a válida.

![Calculadora preta com letras brancas

Descrição gerada automaticamente](Aspose.Words.e49f3e15-de56-4116-acda-732fb2ad1ae8.001.png)

*Figura 8-1: Um teclado simples*

Para realizar o ataque, conectamos duas sondas do osciloscópio ao teclado: uma ao fio de conexão no botão V e outra ao fio de conexão no LED de erro. Em seguida, digitamos o PIN 0000. (Claro, estamos assumindo que temos acesso a uma cópia deste PIN pad que agora dissecámos.) Pressionamos o botão V, observamos nosso traço do osciloscópio e medimos a diferença de tempo entre o botão V sendo pressionado e o LED de erro acendendo. A execução do loop na Listagem 8-1 nos diz que a função levará mais tempo para retornar um resultado com falha se os três primeiros números no PIN estiverem corretos e apenas a verificação final falhar do que levaria se o primeiro número estivesse incorreto desde o início.

O ataque percorre todas as possibilidades para o primeiro dígito do PIN (0000, 1000, 2000, até 9000) enquanto registra o atraso de tempo entre pressionar o botão V e o LED de erro acendendo. A figura 8-2 mostra a sequência de temporização.

![Diagrama, Esquemático

Descrição gerada automaticamente](Aspose.Words.e49f3e15-de56-4116-acda-732fb2ad1ae8.002.png)

Figura 8-2: Determinação do tempo de atraso *do loop*

Esperamos que quando o primeiro dígito PIN estiver correto (digamos que seja um 1), o atraso aumente antes que o LED de erro fique alto, o que acontece somente depois que o segundo dígito for comparado com correct\_pin[]. Agora sabemos o primeiro dígito correto. A parte superior da Figura 8-2 mostra que, quando o botão válido é pressionado após uma sequência completamente incorreta, o LED de erro acende em um curto período de tempo (tbad). Compare isso com o botão válido sendo pressionado após uma sequência parcialmente correta (o primeiro botão estava correto nesta sequência parcial). Agora o LED de erro leva mais tempo (tcorrect) desde que o primeiro número estava correto, mas ao comparar o segundo número, ele liga o LED de erro.

Continuamos o ataque tentando todas as possibilidades para o segundo dígito: inserindo 1000, 1100, 1200 até 1900. Mais uma vez, esperamos que para o dígito correto (digamos que seja 3), o atraso aumente antes que o LED de erro fique alto.

Repetindo esse ataque para o terceiro dígito, determinamos que os três primeiros dígitos são 133. Agora é uma simples questão de adivinhar o dígito final e ver qual deles desbloqueia o sistema (digamos que seja 7). A combinação de PIN é, portanto, 1337. (Considerando o público deste livro, percebemos que podemos ter acabado de publicar seu PIN. Mude-o agora.)

A vantagem desse método é que descobrimos os dígitos incrementalmente conhecendo a posição na sequência PIN do dígito incorreto. Essa pequena informação tem um grande impacto. Em vez de um máximo de 10 × 10 × 10 × 10 palpites, agora precisamos fazer não mais do que 10 + 10 + 10 + 10 = 40 palpites. Se formos bloqueados após três tentativas malsucedidas, a probabilidade de adivinhar o PIN foi melhorada de 3/1000 (0,3%) para 3/40 (7,5%). Além disso, supondo que o PIN seja selecionado aleatoriamente (o que na realidade é uma suposição ruim), encontraríamos, em média, o palpite no meio de nossa sequência de adivinhação. Isso significa que, em média, precisamos adivinhar apenas cinco números para cada dígito, então temos um total médio de 20 palpites com nosso ataque assistido.

Chamamos isso de *ataque temporizado*. Medimos apenas o tempo entre dois eventos e usamos essas informações para recuperar parte do segredo. Pode realmente ser tão fácil na prática? Aqui está um exemplo da vida real.

**Ataque Temporizado de Disco Rígido**

Considere um gabinete de disco rígido com uma partição protegida por PIN — em *particular, o Vantec Vault, número de modelo NSTV290S2*

*Embora este produto não esteja mais disponível nas lojas, você ainda pode encontrar algum estoque antigo. Para obter todos os detalhes deste ataque, consulte a PoC disponível gratuitamente || vá embora 0x04, disponível em espelhos on-line como https://archive.org/stream/pocorgtfo04#page/ n36/mode/1up/ (e também disponível em formato encadernado da No Starch Press em PoC || ir embora)*

O compartimento do disco rígido do Vault funciona mexendo na tabela de partições da unidade para que ela não apareça no sistema operacional do host; o gabinete não criptografa nada. Quando o PIN correto é inserido no Vault, as informações de partição válidas são disponibilizadas ao sistema operacional

A maneira mais óbvia de atacar o Vault pode ser reparar a tabela de partições manualmente na unidade, mas também podemos usar um ataque de temporização contra sua lógica de entrada de PIN — mais alinhada com nossa análise de energia de canal lateral.

Ao contrário do exemplo do PIN pad discutido anteriormente, primeiro precisamos determinar quando um botão é lido, porque neste dispositivo, o microcontrolador apenas ocasionalmente verifica os botões. Cada varredura requer a verificação do status de cada botão para determinar se ele foi pressionado. Essa técnica de varredura é padrão em hardware que deve receber entrada de botões. Ele libera o microcontrolador no hardware para fazer o trabalho nos cerca de 100ms entre a verificação de pressionamentos de botões, o que mantém a ilusão de resposta instantânea para nós humanos comparativamente lentos e desajeitados.

Ao realizar uma varredura, o microcontrolador define alguma linha para uma tensão positiva (alta). Podemos usar essa transição como um gatilho para indicar quando um botão está sendo lido. Enquanto um botão é pressionado, o atraso de tempo dessa linha indo alto para o evento de erro nos dá as informações de tempo que precisamos para o nosso ataque. A Figura 8-3 mostra que a linha B sobe somente quando o microcontrolador está lendo o status do botão e o botão está sendo pressionado ao mesmo tempo. Nosso principal desafio é acionar a captura quando esse alto valor se propaga pelo botão, não apenas quando o botão é pressionado.

![Diagrama

Descrição gerada automaticamente com confiança média](Aspose.Words.e49f3e15-de56-4116-acda-732fb2ad1ae8.003.png)

*Figura 8-3: Diagrama de temporização de ataque ao disco rígido*

Este exemplo simples mostra como o microcontrolador verifica o estado do botão apenas a cada 50ms, como mostrado pela linha de temporização superior A. Ele pode detectar o botão pressionado apenas durante breves pulsos altos nesses intervalos de 50ms. A presença de um botão pressionado é indicada pelo pulso alto correspondentemente breve que o pulso da linha A permite passar para a linha B.

A Figura 8-4 mostra os botões ao longo do lado direito do compartimento do disco rígido pelos quais um código PIN de seis dígitos é inserido. Somente quando todo o PIN correto é inserido é que o disco rígido revela seu conteúdo para o sistema operacional.

Acontece que o código PIN correto em nosso disco rígido é 123456 (a mesma combinação de nossa bagagem), e a Figura 8-5 demonstra como podemos ler isso.

A linha superior é o sinal de erro e a linha inferior é o sinal de varredura de botão. Os cursores verticais são alinhados à borda ascendente do sinal de varredura de botão e à borda descendente do sinal de erro. Estamos interessados na diferença de tempo entre esses cursores, que corresponde ao tempo que o microcontrolador precisa processar a entrada do PIN antes de responder com um erro.

Olhando para a parte superior da figura, vemos as informações de tempo em que o primeiro dígito está incorreto. O atraso de tempo entre a primeira borda ascendente da varredura do botão e a borda descendente do sinal de erro nos dá o tempo de processamento. Em comparação, a parte inferior da figura mostra as mesmas formas de onda quando o primeiro dígito está correto. Observe que o atraso de tempo é um pouco maior. Esse atraso maior é devido ao loop de verificação de senha aceitar o primeiro dígito e, em seguida, ir verificar o próximo dígito. Dessa forma, podemos identificar o primeiro dígito da senha.

![Uma imagem contendo no interior, mesa, circuito, segurando

Descrição gerada automaticamente](Aspose.Words.e49f3e15-de56-4116-acda-732fb2ad1ae8.004.png)

*Figura 8-4: Compartimento do disco rígido do NSTV290S2 do Vantec Vault*

![Interface gráfica do usuário

Descrição gerada automaticamente](Aspose.Words.e49f3e15-de56-4116-acda-732fb2ad1ae8.005.png)

*Figura 8-5: Medição de temporização do disco rígido*

O próximo estágio do ataque é iterar todas as opções para o segundo dígito (ou seja, testar 106666, 116666 . . . 156666, 166666) e procurando um salto semelhante no atraso de processamento. Esse salto no atraso novamente indica que encontramos o valor correto de um dígito e podemos atacar o próximo dígito.

Podemos usar um ataque de cronometragem para adivinhar a senha do Vault em (no máximo) 60 palpites (10 + 10 + 10 + 10 + 10 + 10), o que não deve levar mais de 10 minutos fazendo isso manualmente. No entanto, a fabricante afirma que o Vault tem um milhão de combinações (10 × 10 × 10 × 10 × 10 × 10), o que é verdade ao inserir palpites do PIN. No entanto, nosso ataque de tempo reduz o número de combinações que realmente precisamos para tentar 0,006% do número total de combinações. Nenhuma contramedida, como atrasos aleatórios, complica nosso ataque, e a unidade não fornece um mecanismo de bloqueio que impeça o usuário de inserir um número ilimitado de palpites.

**Medições de energia para ataques de temporização**

Digamos que, em uma tentativa de impedir um ataque de temporização, alguém inseriu um pequeno atraso aleatório antes de acender o LED de erro. A verificação de senha subjacente é a mesma que na Listagem 8-1, mas agora o intervalo de tempo entre pressionar o botão V e o LED de erro acendendo não indica mais claramente a posição de um dígito incorreto.

Agora suponha que somos capazes de medir o consumo de energia do microcontrolador que está executando o código. (Explicaremos como fazer isso na seção "Preparando o osciloscópio" no Capítulo 9.) O consumo de energia pode se parecer com a Figura 8-6, que mostra o rastreamento de energia de um dispositivo enquanto ele está executando uma operação.

![Gráfico

Descrição gerada automaticamente](Aspose.Words.e49f3e15-de56-4116-acda-732fb2ad1ae8.006.png)

*Figura 8-6: Uma amostra de rastreamento de consumo de força de um dispositivo executando uma operação*

Observe a natureza repetitiva do rastreamento de consumo de energia. As oscilações ocorrerão a uma taxa semelhante à frequência de operação do microcontrolador. A maior parte da atividade de comutação de transistor no chip acontece nas bordas do relógio e, portanto, o consumo de energia também aumenta perto desses momentos. O mesmo princípio se aplica até mesmo a dispositivos de alta velocidade, como microcontroladores Arm ou hardware personalizado.

Podemos obter algumas informações sobre o que um dispositivo está fazendo com base nessa assinatura de energia. Por exemplo, se o atraso aleatório discutido anteriormente for implementado como um loop simples para que conta de 0 a um número aleatório n, ele aparecerá como um padrão que é repetido n vezes. Na janela B da Figura 8-6, um padrão (neste caso, o pulso simples) é repetido quatro vezes, portanto, se esperarmos um atraso aleatório, essa sequência de quatro pulsos pode ser o atraso. Se gravarmos alguns desses traços de energia usando o mesmo PIN, e todos os padrões são os mesmos, exceto por diferentes números de pulsos semelhantes à janela B, isso indicaria um processo aleatório em torno da janela B. Essa aleatoriedade poderia ser um processo verdadeiramente aleatório ou algum processo pseudoaleatório (pseudoaleatório normalmente sendo um processo puramente determinístico gerando a "aleatoriedade"). Por exemplo, se você redefinir o dispositivo, poderá ver as mesmas repetições consecutivas na janela B, o que indica que não é realmente aleatório. Mas mais interessante, se variarmos o PIN e vermos o número de padrões que se parecem com os da janela A mudam, temos uma boa ideia de que a sequência de energia ao redor da janela A representa a função de comparação. Assim, podemos concentrar nosso ataque de tempo nessa seção do traço de poder.

A diferença entre essa abordagem e ataques de temporização anteriores é que não precisamos medir o tempo em um algoritmo inteiro, mas podemos escolher partes específicas de um algoritmo que tenham um sinal característico. Podemos usar técnicas semelhantes para quebrar implementações criptográficas, como descreveremos a seguir.

**Análise de energia simples**

Tudo é relativo, assim como a simplicidade da *simple power analysis* (SPA) com relação à *differential power analysis* (DPA). O termo *simple power analysis* tem suas origens no artigo de 1998 "Análise Diferencial de Potência" de Paul Kocher, Joshua Jaffe e Benjamin Jun, onde SPA foi cunhado junto com o DPA mais complexo. Tenha em mente, no entanto, que a execução de SPA às vezes pode ser mais complexa do que executar DPA em alguns cenários de vazamento. Você pode executar um ataque SPA observando uma única execução do algoritmo, enquanto um ataque DPA envolve várias execuções de um algoritmo com dados variados. O DPA geralmente analisa diferenças estatísticas entre centenas a bilhões de vestígios. Embora você possa executar o SPA em um único rastreamento, ele pode envolver de alguns a milhares de rastreamentos — os rastreamentos adicionais são incluídos para reduzir o ruído. O exemplo mais básico de um ataque de SPA é inspecionar visualmente os rastreamentos de energia, o que pode quebrar implementações criptográficas fracas ou verificações de PIN, como mostrado anteriormente neste capítulo.

O SPA baseia-se na observação de que cada instrução do microcontrolador tem sua própria aparência característica nos traços de consumo de energia. Por exemplo, uma operação de multiplicação pode ser distinguida de uma instrução de carga: microcontroladores usam circuitos diferentes para lidar com instruções de multiplicação do circuito que usam ao executar instruções de carga. O resultado é uma assinatura única de consumo de energia para cada processo.

O SPA difere do ataque de temporização discutido na seção anterior, pois o SPA permite examinar a execução de um algoritmo. Você pode analisar o tempo de operações individuais e perfis de potência identificáveis de operações. Se qualquer operação depender de uma chave secreta, você poderá determinar essa chave. Você pode até mesmo usar ataques de SPA para recuperar segredos quando não pode interagir com um dispositivo e pode observá-lo apenas enquanto ele está executando a operação criptográfica.

**Aplicando o SPA à RSA**

Vamos aplicar a técnica de SPA a um algoritmo criptográfico. Vamos nos concentrar na criptografia assimétrica, onde analisaremos as operações usando a chave privada. O primeiro algoritmo a ser considerado será o sistema de criptografia RSA, onde investigaremos uma operação de descriptografia. No núcleo do criptossistema RSA está o algoritmo de exponenciação modular, que calcula <i>m<sup>e</sup> = c</i> mod <i>n</i>, onde <i>m</i> é a mensagem, <i>c</i> é o texto cifrado e mod <i>n</i> é a operação do módulo. Se você não está familiarizado com RSA, recomendamos pegar <i>Serious Cryptography</i> de Jean-Philippe Aumasson (também publicado pela No Starch Press), que cobre a teoria de maneira acessível. Também fornecemos uma visão geral rápida da RSA no Capítulo 6, mas para o trabalho a seguir, você não precisa entender nada sobre a RSA além do fato de que ela processa dados e uma chave secreta.

Essa chave secreta faz parte do processamento feito no algoritmo de exponenciação modular, e a Listagem 8-2 mostra uma possível implementação de um algoritmo de exponenciação modular.

unsigned int do\_magic(unsigned int secret\_data, unsigned int m, unsigned int n) {

`	`unsigned int P = 1;

`	`unsigned int s = m;

`	`unsigned int i;

`	`for(i = 0; i < 10; i++) {

`	        `if (i > 0)

`                             `s = (s \* s) % n;

`	        `if (secret\_data & 0x01)

`	              `P = (P \* s) % n;

`                        `secret\_data = secret\_data >> 1;

`	`}

return P;

}

*Listagem 8-2: Uma implementação do algoritmo square-and-multiply*

Esse algoritmo está no centro de uma implementação de RSA que você pode encontrar como ensinado em um livro didático clássico. Esse algoritmo específico é chamado de *square-and-multiply exponentiation*, codificada para uma chave secreta de 10 bits, representada pela variável secret\_data. (Normalmente, o secret\_data seria uma chave muito mais longa no intervalo de milhares de bits, mas para este exemplo, vamos mantê-lo curto.) A variável m é a mensagem que estamos tentando descriptografar. As defesas do sistema terão sido penetradas no ponto em que um invasor determinar o valor de secret\_data. A análise de canal lateral neste algoritmo é uma tática que pode quebrar o sistema. Observe que pulamos o quadrado na primeira iteração. O primeiro se (i > 0) não faz parte do vazamento que estamos atacando; é apenas parte da construção do algoritmo.

O SPA pode ser usado para examinar a execução desse algoritmo e determinar seu caminho de código. Se pudermos reconhecer se P \* s foi executado, podemos encontrar o valor de um bit de secret\_data. Se pudermos reconhecer isso para cada iteração do loop, poderemos literalmente ler o segredo de um traço de osciloscópio de consumo de energia durante a execução do código (veja a Figura 8-7).

Antes de explicarmos como ler esse rastreamento, dê uma boa olhada no traço e tente mapear a execução do algoritmo nele.

![Gráfico, Gráfico de barras

Descrição gerada automaticamente](Aspose.Words.e49f3e15-de56-4116-acda-732fb2ad1ae8.007.png)

*Figura 8-7: Rastreamento de consumo de energia de uma execução square-and-multiply*

Observe alguns padrões interessantes entre aproximadamente 5ms e 12ms (entre 50 e 120 no eixo x unitário de 100μs): blocos de aproximadamente 0,9ms e 1,1ms intercalados entre si. Podemos nos referir aos blocos mais curtos como **Q** (rápido/quick) e aos blocos mais longos como **L** (longos/long). **Q** ocorre 10 vezes e **L** quatro vezes; na sequência, são **QLQQQQQLQQQQL**. Esta é a parte de visualização da análise de sinais de SPA.

Agora precisamos interpretar essas informações relacionando-as a algo secreto. Se assumirmos que s \* s e P \* s são as operações computacionalmente caras, devemos ver duas variações do loop externo: algumas com apenas um quadrado (S, (s \* s)) e outras que são tanto um quadrado e uma multiplicação (SM, (s \* s) seguido por (P \* s)). Ignoramos cuidadosamente o caso i = 0, que não tem (s \* s), mas vamos chegar nisso.

Sabemos que **S** é executado quando um bit é 0, e **SM** é executado quando um bit é igual a 1. Há apenas uma peça faltando: cada bloco no traço equivale a uma única operação **S** ou operação única **M** , ou cada bloco no traço equivale a uma única iteração de loop e, portanto, uma única operação S ou SM combinada? Em outras palavras, nosso mapeamento é {**Q → S, L → M**} ou **{Q → S, L → SM**}?

Uma dica para a resposta está na sequência **QLQQQQQQQQQLQQQL**. Note que cada **L** é precedido por um **Q**, e não há sequências **LL**. De acordo com o algoritmo, cada **M** tem que ser precedido por um **S** (exceto na primeira iteração), e não há sequências **MM**. Isso indica que {**Q → S, L → M**} é o mapeamento correto, pois o mapeamento {**Q → S, L → SM**} provavelmente também teria dado origem a uma sequência **LL**.

Isso nos permite mapear os padrões para operações e operações para bits secretos, o que significa que **QLQQQQQQQQQL** torna-se as operações **SM,S,S,S,SM,SM,S,S,S,SM**. O primeiro bit processado pelo algoritmo é o bit menos significativo da chave, e a primeira sequência que observamos é **SM**. Como o algoritmo ignora o **S** para o bit menos significativo, sabemos que o **SM** inicial deve vir da próxima iteração de loop e, portanto, do próximo bit. Com esse conhecimento, podemos reconstruir a chave: 10001100010.

**Aplicando SPA para RSA, Redux**

A implementação da exponenciação modular em implementações RSA variará e algumas variantes podem exigir mais esforço para serem interrompidas. Mas, fundamentalmente, encontrar diferenças no processamento de um bit 0 ou 1 é o ponto de partida para um ataque de SPA. Como exemplo, a implementação RSA da biblioteca MBED-TLS de código aberto da ARM usa algo *windowing*. Ele processa vários bits do segredo ao mesmo tempo (uma janela/*window*), o que teoricamente significa que o ataque é mais complicado porque o algoritmo não processa bits individuais. Praveen Kumare Vadnala e Lukasz Chmielewski em "Attacking OpenSSL Using Side-Channel Attacks: The RSA Case Study" descreve um ataque completo à implementação de janelas usada pelo MBED-TLS.

Chamamos especificamente a atenção para o fato de que ter um modelo simples é um bom ponto de partida, mesmo quando a implementação não é exatamente igual ao modelo, pois mesmo as melhores implementações podem ter falhas que podem ser explicadas/exploradas pelo modelo simples. A implementação da função de exponenciação modular de janelas usada pelo MBED-TLS versão 2.26.0 na descriptografia RSA é um exemplo disso. Na discussão a seguir, pegamos o arquivo *bignum.c* do MBED-TLS e simplificamos parte da função *mbedtls\_mpi\_exp\_mod* para produzir o código na Listagem 8-3, que assume que temos uma variável \_key secreta contendo a chave secreta e uma variável secret\_key\_size contendo o número de bits a serem processados.

int ei, state = 0;

for( int i = 0; i < secret\_key\_size; i++ ){       #1

`     `ei = (secret\_key >> i) & 1;                            #2

`    `if( ei == 0 && state == 0 )                             #3

`            `// Do nothing, loop for next bit

`      `else:

`          `state = 2;                                                         #4

}

--snip—

*Listagem 8-3: Pseudocódigo de bignum.c mostrando parte do fluxo de implementação do mbedtls\_mpi\_exp\_mod*

Vamos encaminhá-lo para os números de linha originais do arquivo *bignum.c* no MBEDTLS versão 2.26.0 caso você queira encontrar a implementação específica. Para começar, o loop for() externo #1 da Listagem 8-3 é implementado como um loop while(1) no MBED-TLS e pode ser encontrado na linha 2227.

Um bit da chave secreta é carregado na variável ei #2 (linha 2241 no arquivo original). Como parte da implementação de exponenciação modular, a função processará os bits de chave secreta até que o primeiro bit com um valor de 1 seja alcançado. Para executar esse processamento, a variável de estado é um sinalizador que indica se terminamos de processar todos os zeros à esquerda. Podemos ver a comparação em #3, que pula para a próxima iteração do loop se o estado == 0 (o que significa que ainda não vimos um bit 1) e o bit de chave secreta atual (ei) é 0.

Curiosamente, a ordem das operações na comparação #3 acaba por ser uma falha completamente fatal para esta função. O compilador C confiável geralmente executa primeiro a comparação ei == 0 antes da comparação de estado == 0. A comparação ei sempre vaza o valor do bit de chave secreta #4, para todos os bits de chave. Acontece que você pode pegar isso com o SPA.

Se a comparação de estado fosse feita primeiro, em vez disso, a comparação nunca chegaria ao ponto de verificar o valor ei, uma vez que a variável de estado fosse diferente de zero (a variável de estado se torna diferente de zero após o processamento do primeiro bit de chave secreta definido como 1). A correção simples (que pode não funcionar com todos os compiladores) é trocar a ordem da comparação para ser o estado == 0 && ei == 0. Este exemplo mostra a importância de verificar sua implementação como desenvolvedor e o valor em fazer suposições básicas como um invasor.

Como você pode ver, o SPA explora o fato de que diferentes operações introduzem diferenças no consumo de energia. Na prática, você deve ser capaz de ver facilmente diferentes caminhos de instrução quando eles diferem por algumas dezenas de ciclos de relógio, mas essas diferenças se tornarão mais difíceis de ver à medida que os caminhos de instrução se aproximam de tomar apenas um único ciclo. A mesma limitação vale para o consumo de energia dependente de dados: se os dados afetarem muitos ciclos de clock, você deverá ser capaz de ler o caminho, mas se a diferença for apenas uma pequena variação de energia em uma instrução individual, você a verá apenas em alvos particularmente vazados. No entanto, se essas operações estiverem diretamente ligadas a segredos, como na Figura 8-7, você ainda poderá aprender esses segredos.

Uma vez que as variações de energia caem abaixo do nível de ruído, o SPA tem mais um truque na manga antes que você queira mudar para o DPA: processamento de sinal. Se o seu alvo executa suas operações críticas em um tempo constante com dados constantes e um caminho de execução constante, você pode executar novamente as operações do SPA muitas vezes e fazer a média das medições de energia para combater o ruído. Discutiremos a filtragem mais elaborada no Capítulo 11. No entanto, às vezes o vazamento é tão pequeno que precisamos de estatísticas pesadas para detectá-lo, e é aí que entra o DPA. Você aprenderá mais sobre DPA no Capítulo 10.

ATAQUES DE TEMPORIZAÇÃO CRIPTOGRÁFICA

*Assim como o exemplo de código PIN mostrado na Listagem 8-1 tem um tempo de execução que depende dos dados de entrada (e, portanto, vaza variáveis secretas internas), os algoritmos criptográficos também podem ser vulneráveis a ataques de temporização. Estamos nos concentrando na análise de canal lateral de energia neste capítulo, em vez de em técnicas de tempo puro, então daremos apenas uma breve visão geral dos ataques de cronometragem criptográfica aqui.*

*Uma grande referência para ataques de cronometragem criptográfica é um artigo de Paul Kocher lançado em 1996, intitulado "Timing Attacks on Implementations of Diffie Hellman, RSA, DSS, and Other Systems". O ataque de temporização usa o fato de que o tempo de execução de certas operações depende dos bits de chave (os dados secretos). Por exemplo, a Listagem 8-2 apresenta um bloco de código que pode ser encontrado em uma implementação RSA. Observe que o caminho de execução ramifica de forma diferente dependendo se os bits estão definidos, o que, portanto, provavelmente afeta o tempo total de execução. Os ataques de temporização exploram essa ramificação para determinar quais bits de chave foram definidos.*

*Também muito relevantes em sistemas mais complexos são os ataques de temporização de cache. Especificamente, algoritmos que usam tabelas de pesquisa para determinadas operações podem vazar informações revelando qual elemento está sendo acessado quando uma análise de variação de tempo é executada. A premissa básica é que o tempo necessário para acessar um determinado endereço de memória depende se esse endereço está em um cache de memória.*

*Se pudermos medir esse tempo e relacionar os acessos à memória com os segredos que estão sendo processados, estamos no negócio. O artigo de Daniel J. Bernstein de 2005 "Cache-Timing Attacks on AES" demonstra um ataque contra uma implementação OpenSSL do AES. Este vetor de ataque pode ser completamente executado a partir de software, apresentando uma oportunidade não apenas para o invasor de hardware fisicamente acessível, mas também para ataques em redes remotas.*

*Mais tarde, veremos uma maneira melhor de determinar os bits de chave de criptografia para esse mesmo algoritmo usando análise de energia simples, então não discutiremos mais detalhes do ataque de tempo neste capítulo. Para a maioria dos hardwares de sistemas embarcados, é muito mais prático e eficaz atacar usando análise de energia.*

**SPA NA ECDSA**

Esta seção usa o bloco de anotações complementar para este capítulo (disponível em *https://nostarch.com/hardwarehacking/*). Mantenha-o à mão, pois vamos referenciá-lo ao longo desta seção. Os títulos das seções deste livro correspondem aos títulos das seções no bloco de anotações.

**Objetivo e Notação**

O ECDSA (*Elliptic Curve Digital Signature Algorithm*) usa criptografia de curva elíptica/*elliptic curve cryptography* (ECC) para gerar e verificar chaves de assinatura seguras. Nesse contexto, uma assinatura digital aplicada a um documento baseado em computador é usada para verificar criptograficamente se uma mensagem é de uma fonte confiável ou não foi modificada por terceiros.

*O ECC está se tornando uma alternativa mais popular à criptografia baseada em RSA, principalmente porque as chaves ECC podem ser muito mais curtas, mantendo a força criptográfica. A matemática por trás do ECC está muito além do escopo deste livro, mas você não precisa entendê-lo completamente para executar um ataque de SPA nele. Caso em questão: nenhum dos autores compreende completamente a CEC. Só precisamos saber a implementação para entender o ataque.*

O objetivo é usar o SPA para recuperar a chave privada d da execução de um algoritmo de assinatura ECDSA para que possamos usá-lo para assinar mensagens que supostamente sejam o remetente. Em um nível alto, as entradas para uma assinatura ECDSA são a chave privada d, o ponto público G e uma mensagem m, e a saída é uma assinatura (r,s). Uma coisa estranha sobre o ECDSA é que as assinaturas são diferentes todas as vezes, mesmo para a mesma mensagem. (Você verá o porquê daqui a pouco.) O algoritmo de verificação ECDSA verifica uma mensagem usando o ponto público G, a chave pública pd, a mensagem m e a assinatura (r,s) como entradas. Um ponto nada mais é do que um conjunto de coordenadas xy em uma *curva* – daí o C no ECDSA.

Ao desenvolver nosso ataque, nos baseamos no fato de que o algoritmo de assinatura ECDSA usa internamente um número aleatório k. Este número deve ser mantido em segredo, porque se o valor de k de uma determinada assinatura (r,s) é revelado, você pode resolver por d. Vamos extrair k usando SPA e depois resolver para d. Vamos nos referir a k como um *nonce*, porque além de exigir sigilo, ele também deve permanecer único (*nonce* é a abreviação de ”*number used once”*).

Como você pode ver no notebook, algumas funções básicas implementam a assinatura e verificação do ECDSA, e algumas linhas exercem essas funções. Para o restante deste bloco de anotações, criamos uma chave pública/privada aleatória pd/d. Também criamos um hash de mensagem aleatória e (ignorando o hash real de uma mensagem m, o que não é relevante aqui). Realizamos uma operação de assinatura e verificação, apenas para verificar se está tudo bem. A partir daqui, usaremos apenas os valores públicos, mais um rastro de poder simulado, para recuperar os valores privados.

**Encontrando uma operação com vazamento**

Agora, vamos fazer cócegas no seu cérebro. Verifique as funções leaky\_scalar\_mul() e ecdsa\_sign\_leaky(). Como você sabe, estamos atrás de nonce k, então tente encontrá-lo no código. Preste atenção especificamente em como o nonce k é processado pelo algoritmo e crie algumas hipóteses sobre como ele pode vazar em um rastro de energia. Este é um exercício de SPA, então tente identificar as operações dependentes de segredo.

Como você deve ter percebido, vamos atacar o cálculo do nonce k multiplicado pelo ponto público G. Na CCE, essa operação é chamada de *multiplicação escalar* porque multiplica um k escalar com um ponto G.

O algoritmo do livro didático para multiplicação escalar toma os bits de k um a um, como implementado em leaky\_scalar\_mul(). Se o bit for 0, somente uma duplicação de ponto será executada. Se o bit for 1, uma adição de ponto e uma duplicação de ponto serão executadas. Isso é muito parecido com a exponenciação modular RSA do livro didático e, como tal, também leva a um vazamento de SPA. Se você puder diferenciar entre apenas duplicação de pontos e adição de pontos seguida de duplicação de pontos, você poderá encontrar os bits individuais de k. Como mencionado anteriormente, podemos então calcular a chave privada d completa.

**Simulando vestígios de SPA de um ECDSA vazado**

No bloco de anotações, ecdsa\_sign\_leaky() assina uma determinada mensagem com uma determinada chave privada. Ao fazer isso, ele vaza o tempo simulado das iterações de loop na multiplicação escalar implementada em leaky\_scalar\_mul(). Estamos obtendo esse tempo por amostragem aleatória de uma distribuição normal. Em um alvo real, as características de tempo serão diferentes do que fazemos aqui.

No entanto, qualquer diferença de tempo mensurável entre as operações será explorável da mesma maneira.

Em seguida, transformamos os tempos em um rastreamento de potência simulado usando a função timeleak\_to\_trace(). O início de tal traço será traçado no caderno; A Figura 8-8 também mostra um exemplo.

![Gráfico

Descrição gerada automaticamente](Aspose.Words.e49f3e15-de56-4116-acda-732fb2ad1ae8.008.png)

*Figura 8-8: Rastreamento de consumo de energia ECDSA simulado mostrando nonce bits*

Neste rastreamento simulado, você pode ver um vazamento de tempo de SPA em que os loops que executam duplicações de ponto (nonce k bit secreto = 0) são mais curtos em duração do que os loops que executam adição de ponto e duplicação de ponto (nonce k bit secreto = 1).

**Medindo a Duração do Malha de Multiplicação Escalar**

Ao atacar um nonce desconhecido, teremos um traço de poder, mas não sabemos os bits para k. Para tanto, analisamos as distâncias entre os picos utilizando trace\_to\_difftime() no caderno. Esta função primeiro aplica um limite vertical aos traços para se livrar do ruído de amplitude e transformar o rastreamento de potência em um traço "binário". O *power trace* agora é uma sequência de 0 (baixa) e 1 (alta) amostras.

Estamos interessados na duração de todas as sequências de uns porque eles medem a duração do ciclo de multiplicação escalar. Por exemplo, a sequência [1, 1, 1, 1, 0, 1, 0, 0, 1, 1] se transforma nas durações [5, 1, 2], correspondentes ao número de sequências. Aplicamos um pouco de magia NumPy (explicada com mais detalhes no caderno) para realizar essa conversão. Em seguida, plotamos essas durações em cima do traço binário; A Figura 8-9 mostra o resultado.

![Gráfico, Gráfico de barras

Descrição gerada automaticamente](Aspose.Words.e49f3e15-de56-4116-acda-732fb2ad1ae8.009.png)

*Figura 8-9: Rastreamento binário de consumo de energia ECDSA mostrando vazamento de temporização de SPA*

**De durações à bits**

Em um mundo ideal, teríamos durações "longas" e "curtas", bem como um ponto de corte que separa corretamente as duas. Se uma duração estiver abaixo do ponto de corte, teríamos apenas duplicação de pontos (bit secreto 0), ou, como mostrado anteriormente, teríamos adição de ponto e duplicação de pontos (bit secreto 1). Infelizmente, na realidade, o jitter de tempo fará com que esse SPA ingênuo falhe porque o ponto de corte não é capaz de separar as duas distribuições perfeitamente. Você pode ver esse efeito no bloco de anotações e na Figura 8-10.![Gráfico, Histograma

Descrição gerada automaticamente](Aspose.Words.e49f3e15-de56-4116-acda-732fb2ad1ae8.010.png)

*Figura 8-10: A distribuição das durações para uma sobreposição double-only (esquerda) e double-and-add (direita), não permitindo que a duração seja um preditor perfeito*

Como resolver isso? Um insight importante é que temos uma boa ideia de quais bits provavelmente estão incorretos: ou seja, os que estão mais próximos do ponto de corte. No notebook, a função simple\_power\_analysis() analisa a duração de cada operação. Com base nessa análise, ele gera um valor adivinhado para k e uma lista de bits em k que estão mais próximos do ponto de corte. O ponto de corte é determinado como a média das porcentagens 25 e 75 na distribuição de duração, pois esta é mais estável do que tomar a média.

**Brute-Forcing a saída**

Como temos um palpite inicial de k e os bits mais próximos do ponto de corte, podemos simplesmente forçar esses bits. No caderno, fazemos isso na função bruteforce(). Para todos os candidatos a k, um valor da chave privada d é calculado.

A função tem dois meios de verificar se encontrou o d correto. Se ele tiver acesso ao d correto, ele pode trapacear comparando o d calculado com o d correto. Se ele não tiver acesso ao d correto, ele calcula a assinatura (r,s) a partir do k adivinhado e calculado d e, em seguida, verifica se essa assinatura está correta. Esse processo é muito, muito mais lento, mas é algo que você enfrentará ao fazer isso de verdade.

Mesmo esse ataque de força bruta nem sempre renderá o nonce correto, então o colocamos em um loop gigante para você. Deixe-o funcionar por um tempo, e ele recuperará a chave privada simplesmente de apenas tempos de SPA. Depois de algum tempo, você verá algo como a Listagem 8-4.

Attempt 16

Guessed k:  0b1111111100011001010111100001101011000111000000110011110100110011

1101000100001011011011001001100100110000001110100011011101010101101000111001

100001000110000001010000110111101000000001001001000011011011110000110100111101

0110001000110011101000010010100101101

Actual k: 0b1111111100011001010111100001101011000111000010110011110100110011

1101000100001011011011001001111100110000001110100011011101010101101000111001

100001000110000001010000110111101000000001001001000011111011110000110100111101

0110001000110011101000010010100101101

Bit errors: 4

Bruteforcing bits: [241 60 209 160 161 212 34 21]

No key for you.

Attempt 17

Guessed k: 0b1111101110111000100101000010000110101100000010011100000101101001

1010010000110110000110010010011111000110110111011100110001110101010110000000

100110001111101000110010001101001100011101101010111000110111110011101001011110

010100011101100011100011011000100

Actual k: 0b1111101110111000100101000010000110101100000011011100000101101001

1010010000110110000110010110011111000110110111011101110001110101010110000000

100110011111101000111010001101001100011101101010111000110111110011101001011110

010100011101101011100011011000100

Bit errors: 6

Bruteforcing bits: [103 185 135 205 18 161 90 98]

Yeash! Key found:0b11010100100000000001000110001100001010010110101110000110100

110001011101110111100001110011110110100001010000011100100111111001011110000101

000100101001011110011010010000000100111000101011110010000010010101001010111010

1001110110100010011100000001100101110

*Listagem 8-4: Saída do ataque de ECDSA SPA do Python*

Depois de ver isso, o algoritmo SPA recuperou com sucesso a chave apenas de algumas medições barulhentas das durações simuladas da multiplicação escalar.

Esse algoritmo foi escrito para ser bastante portátil para outras implementações ECC (ou RSA). Se você está indo atrás de um alvo real, primeiro criar uma simulação como este bloco de anotações que imita a implementação é recomendado apenas para mostrar que você pode fazer positivamente a extração de chaves. Caso contrário, você nunca saberá se seu SPA falhou por causa do ruído ou porque você tem um bug em algum lugar.

**Resumo**

A análise de energia é uma forma poderosa de ataque de canal lateral. O tipo mais básico de análise de energia é uma extensão simples de um ataque de canal lateral de temporização, que dá melhor visibilidade sobre o que um programa está executando internamente. Neste capítulo, mostramos como a simples análise de energia pode quebrar não apenas as verificações de senha, mas também alguns sistemas criptográficos reais, incluindo implementações RSA e ECDSA.

Realizar esse rastreamento teórico e simulado pode não ser suficiente para convencê-lo de que a análise de energia é realmente uma ameaça a um sistema seguro. Antes de prosseguir, em seguida, vamos levá-lo através da configuração para um laboratório básico. Você colocará as mãos em algum hardware e executará ataques básicos de SPA, permitindo que você veja o efeito de alterar instruções ou fluxo de programa no rastreamento de energia. Depois de explorar como a medição de análise de potência funciona, veremos as formas avançadas de análise de energia nos capítulos subsequentes.
